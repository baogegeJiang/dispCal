from . import disp as disp
name = 'disp'